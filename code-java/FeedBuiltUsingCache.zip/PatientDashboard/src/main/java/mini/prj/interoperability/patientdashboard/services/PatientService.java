package mini.prj.interoperability.patientdashboard.services;

import org.springframework.stereotype.Service;


public class PatientService {



}
