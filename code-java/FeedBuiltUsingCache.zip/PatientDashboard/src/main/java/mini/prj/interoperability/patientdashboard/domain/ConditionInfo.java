package mini.prj.interoperability.patientdashboard.domain;

public class ConditionInfo {

}
