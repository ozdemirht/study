package com.future.threads;

import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.*;
import java.util.function.Predicate;
import java.util.function.Supplier;

import static java.lang.Thread.sleep;

public class ThreadExample {


    public static void main(String[] args) throws InterruptedException {

        Runnable runnable1 = new Runnable() {
            @Override
            public void run() {
                    System.out.println("MyRunnable with inner class running");
            }
        };
        Thread thread1 = new Thread(runnable1);
        thread1.start();
        Thread thread2 = new Thread(()-> {
            System.out.println("MyRunnable with lambda running");

        });
        thread2.start();

        Runnable runnable3 =()-> {
            System.out.println("MyRunnable with second lambda running");

        };
        Thread thread3 = new Thread(runnable3);
        thread3.start();
    }
}

