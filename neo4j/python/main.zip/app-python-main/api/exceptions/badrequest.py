class BadRequestException(Exception):
    pass